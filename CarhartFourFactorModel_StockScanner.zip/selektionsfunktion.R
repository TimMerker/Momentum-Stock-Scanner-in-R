library(tidyquant)
library(tidyverse)
library(timetk)
library(broom)
library(glue)


# Code based on: http://www.calculatinginvestor.com/2011/04/19/fama-french-tutorial/ 
# Extended to Carhart four-factor model

# Fama-French ~ Carhart Regression example in R

# Load CSV file into R
ff_factor <- read.table("F-F_Research_Data_Factors.csv",header=TRUE,sep=",")
ff_momentum <- read.table("F-F_Momentum_Factor.csv",header=TRUE,sep=",")

# Extract Fama-French Factors
rmrf <- ff_factor[,2]/100
smb <- ff_factor[,3]/100
hml <- ff_factor[,4]/100
rf <- ff_factor[,5]/100
mom <- ff_momentum[,2]/100

previousyear =  ymd(Sys.Date()) - years(1)
# We want full months
yesterday = Sys.Date() - 1 

# Apple monthly prices
getSymbols("AAPL",from = previousyear, to = yesterday,  periodicity = 'monthly')
chartSeries(AAPL)

# Monthly returns
return <- CalculateReturns(AAPL$AAPL.Close)
return <- return[-1]

# Calculate Excess Returns for Target Stock
stock.excess <- return - tail(rf,11)

# Run Fama-French Regression
ffregression <- lm(stock.excess ~ tail(rmrf,11) + tail(smb,11) + tail(hml,11) + tail(mom,11))

# Print summary of regression results
print(summary(ffregression))