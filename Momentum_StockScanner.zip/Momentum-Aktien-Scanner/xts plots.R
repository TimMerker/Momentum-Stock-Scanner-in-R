# Zwei XTS-Objekte unterschiedlicher L�nge sinnvoll plotten
# devtools::install_github("rstudio/chromote")

library (httr)
library (xml2)
library (R.utils)
library (xts)
library (quantmod)
library (chromote)
library (rvest)
library (stringr)
library (pracma)
library (data.table)
library (lubridate)
library (ggthemes)
library (gridExtra)
library (cowplot)
library (ggplot2)
library (tidyquant)
library (gridExtra)
library (RWeka)
library (eRic)
library (ggrepel)

# remotes::install_github("etlundquist/eRic")

# Hilfsfunktion: + =   String-Konkatenation
"+" <- function(...) UseMethod("+") 
"+.default" <- .Primitive("+") 
"+.character" <- function(...) paste(...,sep="")

options (warn = -1)

#----------------------------------------------------------------------------------------

#x <- read.csv ("c:\\a\\finance db\\t7-xfra-BF-allTradableInstruments.csv", sep = ";")

load_isin_db <- function()
{
  isin_db <<- read.csv ("C:\\Users/timme/Desktop/Forschungspraktikum/Momentum-Aktien-Scanner/finance db\\isins.csv", sep = ";")
  isin_db2 <<- read.csv ("C:\\Users/timme/Desktop/Forschungspraktikum/Momentum-Aktien-Scanner/finance db\\isins2.csv", sep = ";")
  isin_db3 <<- read.csv ("C:\\Users/timme/Desktop/Forschungspraktikum/Momentum-Aktien-Scanner/finance db\\isins4.csv", sep = ";") # Absicht, 3 = alt
  isin_db4 <<- read.csv ("C:\\Users/timme/Desktop/Forschungspraktikum/Momentum-Aktien-Scanner/finance db\\isins4.csv", sep = ";")
  isin_db2 <<- isin_db2[which (isin_db2$Instrument.Type == "Equity"),]
  isin_db3 <<- isin_db3[which (isin_db3$Product.Assignment.Group.Description == "BOERSE FRANKFURT EQUITIES"),]
  isin_db4 <<- isin_db4[which (isin_db4$Instrument.Type == "ETF"),]
  isin_db2 <<- isin_db2[which ((isin_db2$Instrument.Group %in% "EQ00") | (isin_db2$Instrument.Group %in% "EQ01")),]
}

#----------------------------------------------------------------------------------------

# Kurslisten
if (!exists ("isin_db")) load_isin_db()
dax_isins <- as.character (isin_db[which (isin_db$Product.Assignment.Group.Description == "DAX"),]$ISIN)
mdax_isins <- as.character (isin_db[which (isin_db$Product.Assignment.Group.Description == "MDAX"),]$ISIN)
sdax_isins <- as.character (isin_db[which (isin_db$Product.Assignment.Group.Description == "SDAX"),]$ISIN)

# F�r Scraper
user_agent <- "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36"
httr::set_config (httr::user_agent (user_agent))

#----------------------------------------------------------------------------------------

# Hilfsfunktion: + =   String-Konkatenation
"+" <- function(...) UseMethod("+") 
"+.default" <- .Primitive("+") 
"+.character" <- function(...) paste(...,sep="")

#----------------------------------------------------------------------------------------

normalize <- function (what)
{
  result <- round ((what - mean (what)) / sd (what), 2)
  result <- tail (result, 1)
  return (result)
}

#----------------------------------------------------------------------------------------

max_diff_min <- function (what)
{
  result <- round (max (what) - min (what), 4)
  return (result)
}

#----------------------------------------------------------------------------------------

max_div_min <- function (what)
{
  result <- round (max (what) / min (what), 4)
  return (result)
}

#----------------------------------------------------------------------------------------

if (!exists ("temp_plus")) temp_plus <- get ("+", envir = .GlobalEnv)
switch_plus <- function (value)
{
  check <- try ("a" + "b", silent = T)
  if ((class (check) == "try-error") & (value == TRUE))
  {
    assign ("+", temp_plus, envir = .GlobalEnv)
    return (TRUE)
  }
  else
  {
    suppressWarnings (rm ("+", envir = .GlobalEnv))
    return (FALSE)
  }
}

#----------------------------------------------------------------------------------------

strength_chart <- function (id = "US5002551043", start = 2019)
{
  if (nchar (id) == 12)
  {
    isin <- id
    symbol <- isin_to_symbol_yahoo (id)
  }
  else
  {
    isin <- symbol_to_isin (id)
    symbol <- id
  }
  
  a <- get_stock_data (id)
  b <- get_stock_data ("SPY")
  c <- prepare_plot (a, b)
  c <- c[toString (start) + "/"]
  
  min_a <- min (which (!is.na (c$Close)))
  min_b <- min (which (!is.na (c$Close.1)))
  c <- c[max (min_a, min_b):nrow (c),]
  
  c$Close <- as.numeric (c$Close) / c$Close[[1]]
  c$Close.1 <- as.numeric (c$Close.1) / c$Close.1[[1]]
  
  c$Quote <- round (c$Close / c$Close.1, 2)
  c$Quote_norm <- runningfunction (c$Quote, functionname = "max_div_min", windowsize = 3)
  c$Quote_norm <- runningfunction (c$Quote_norm, functionname = "normalize", windowsize = 60)
  
  c$MA21 <- runningfunction (c$Quote, functionname = "mean", windowsize = 21)
  c$MA100 <- runningfunction (c$Quote, functionname = "mean", windowsize = 42)
  
  security_name <- id_to_name (id)
  plot_title <- "Strength Chart of " + security_name + " (" + isin + ") VS: SNP500"
  plot_title <- str_replace_all (plot_title, "  ", "")
  
  switch_plus (FALSE)
  
  p1 <- c %>%
    ggplot (aes (x = Index, y = Quote)) + 
    geom_line (aes (y = Quote), size = 1, colour = "Blue") +
    geom_line (aes (y = MA21), size = 1, colour = "Brown") +
    geom_line (aes (y = MA100), size = 1, colour = "Red") +
    labs (title = plot_title, y = "Relative Strength", x = "Year") + 
    theme_tq()
  
  p2 <- c %>%
    ggplot (aes (x = Index, y = Quote)) + 
    geom_line (aes (y = Quote_norm), size = 1, colour = "Blue") +
    theme_tq()
  
  switch_plus (TRUE)
  
  plot (plot_grid (p1, p2, align = "v", nrow = 2, rel_heights = c(3/4, 1/4)))
}

#----------------------------------------------------------------------------------------

my_chart <- function (id)
{
  if (nchar (id) == 12)
  {
    isin <- id
    symbol <- isin_to_symbol_yahoo (id)
  }
  else
  {
    isin <- symbol_to_isin (id)
    symbol <- id
  }
  
  if (anyNA (symbol)) return (NA)
  f <- grab_fundamentals (isin)
  
  if (anyNA (f)) return (NA)
  k <- get_stock_data (isin)
  
  kbvs <- as.numeric (f$fundamentals["KBV (Kurs/Buchwert)",])
  kbv_median <- median (kbvs, na.rm = T)
  
  kgvs <- as.numeric (f$fundamentals["KGV (Kurs/Gewinn)",])
  kgv_median <- median (kgvs, na.rm = T)
  
  kuvs <- as.numeric (f$fundamentals["KUV (Kurs/Umsatz)",])
  kuv_median <- median (kuvs, na.rm = T)
  
  kcfs <- as.numeric (f$fundamentals["KCV (Kurs/Cashflow)",])
  kcf_median <- median (kcfs, na.rm = T)
  
  renditen <- as.numeric (f$fundamentals["Gesamtkapitalrendite in %",])
  
  ergebnisse <- f$fundamentals["Ergebnis je Aktie (unverw�ssert)",]
  ergebnisse_xts <- xts (x = as.numeric (ergebnisse), order.by = as.Date ("01-01-" + colnames (ergebnisse), format = "%d-%m-%Y"))
  
  ergebnisse2 <- f$fundamentals["Buchwert je Aktie",]
  ergebnisse2_xts <- xts (x = as.numeric (ergebnisse2), order.by = as.Date ("01-01-" + colnames (ergebnisse2), format = "%d-%m-%Y"))
  
  ergebnisse3 <- f$fundamentals["Umsatz je Aktie",]
  ergebnisse3_xts <- xts (x = as.numeric (ergebnisse3), order.by = as.Date ("01-01-" + colnames (ergebnisse3), format = "%d-%m-%Y"))
  
  ergebnisse4 <- f$fundamentals["Cashflow je Aktie",]
  ergebnisse4_xts <- xts (x = as.numeric (ergebnisse4), order.by = as.Date ("01-01-" + colnames (ergebnisse4), format = "%d-%m-%Y"))
  
  ergebnisse5 <- f$fundamentals["Gesamtkapitalrendite in %",]
  ergebnisse5_xts <- xts (x = as.numeric (ergebnisse5), order.by = as.Date ("01-01-" + colnames (ergebnisse5), format = "%d-%m-%Y"))
  
  ergebnisse6 <- f$fundamentals["Eigenkapitalquote in %",]
  ergebnisse6_xts <- xts (x = as.numeric (ergebnisse6), order.by = as.Date ("01-01-" + colnames (ergebnisse6), format = "%d-%m-%Y"))
  
  ergebnisse7 <- f$fundamentals["Dividendenrendite in %",]
  ergebnisse7_xts <- xts (x = as.numeric (ergebnisse7), order.by = as.Date ("01-01-" + colnames (ergebnisse7), format = "%d-%m-%Y"))
  
  combined <- prepare_plot (k, ergebnisse_xts)
  colnames (combined)[ncol (combined)] <- "earnings"
  
  combined <- prepare_plot (combined, ergebnisse2_xts)
  colnames (combined)[ncol (combined)] <- "buchwerte"
  
  combined <- prepare_plot (combined, ergebnisse3_xts)
  colnames (combined)[ncol (combined)] <- "umsaetze"
  
  combined <- prepare_plot (combined, ergebnisse4_xts)
  colnames (combined)[ncol (combined)] <- "cashflows"
  
  combined <- prepare_plot (combined, ergebnisse5_xts)
  colnames (combined)[ncol (combined)] <- "g_renditen"
  
  combined <- prepare_plot (combined, ergebnisse6_xts)
  colnames (combined)[ncol (combined)] <- "ek_quote"
  
  combined <- prepare_plot (combined, ergebnisse7_xts)
  colnames (combined)[ncol (combined)] <- "div_rendite"
  
  combined$year <- as.numeric (year (as.POSIXlt (index (combined))))
  
  combined <- combined [which (!is.na (combined$Open)),]
  
  #fit <- lm (Close ~ earnings + buchwerte + umsaetze + cashflows + g_renditen + ek_quote + div_rendite + year, data = combined)
  model <- make_Weka_classifier ("weka/classifiers/functions/LinearRegression")
  fit <- model (as.formula ("Close ~ earnings + buchwerte + umsaetze + cashflows + g_renditen + ek_quote + div_rendite + year"), data = data.frame (combined), control = c(), na.action = NULL)
  
  prediction <- predict (fit, combined)
  #ergebnisse_final_xts <- xts (x = as.numeric (prediction), order.by = as.Date (labels (prediction), format = "%Y-%m-%d"))
  ergebnisse_final_xts <- xts (x = prediction, order.by = as.Date (index (combined), format = "%Y-%m-%d"))
  
  fit2 <- model (as.formula ("Close ~ earnings + buchwerte + umsaetze + cashflows + g_renditen + ek_quote + div_rendite + year"), data = data.frame (combined["/2019"]), control = c(), na.action = NULL)
  prediction2 <- predict (fit2, combined)
  ergebnisse_final_xts2 <- xts (x = prediction2, order.by = as.Date (index (combined), format = "%Y-%m-%d"))
  
  combined <- prepare_plot (combined, ergebnisse_final_xts)
  colnames (combined)[ncol (combined)] <- "model"
  
  combined <- prepare_plot (combined, ergebnisse_final_xts2)
  colnames (combined)[ncol (combined)] <- "model2"
  
  security_name <- id_to_name (id)
  plot_title <- "Lynch Chart of " + security_name + " (" + isin + ") - Median-PE: " + kgv_median + " - Median-PB: " + kbv_median + " - Median-PR: " + kuv_median + " - Model: " + round (tail (combined$model, 1), 2)
  plot_title <- str_replace_all (plot_title, "  ", "")
  switch_plus (FALSE)
  
  suppressWarnings (plot (combined %>%
                            ggplot (aes (x = Index, y = buchwerte)) + 
                            geom_barchart (aes (open = Open, high = High, low = Low, close = Close)) + 
                            geom_line (aes (y = model2), size = 1, colour = "Red") +
                            geom_line (aes (y = model), size = 1, colour = "Blue") +
                            # geom_line (aes (y = earnings), size = 1, colour = "Blue") +
                            # geom_line (aes (y = buchwerte), size = 1, colour = "Green") +
                            # geom_line (aes (y = umsaetze), size = 1, colour = "Brown") +
                            # ylim (0, max (max (combined$Close, combined$earnings, combined$buchwerte, combined$umsaetze, combined$model, combined$cashflows))) + 
                            labs (title = plot_title, y = "Closing Price", x = "Year") + 
                            theme_tq()))
  
  switch_plus (TRUE)
}

#----------------------------------------------------------------------------------------

get_stock_data_realtime <- function (id)
{
  if (nchar (id) == 12)
  {
    isin <- id
    symbol <- isin_to_symbol_yahoo (id)
  }
  else
  {
    isin <- symbol_to_isin (id)
    symbol <- id
  }
  
  if (anyNA (symbol)) return (NA)
  
  url <- 'https://finance.yahoo.com/quote/' + symbol
  
  check <- try (suppressWarnings (withTimeout (html <- GET (url), timeout = 5)), silent = T)
  if (class (attributes (check)$condition)[1] == "TimeoutException")
  {
    Sys.sleep (1)
    return (get_stock_data_realtime (id = id))
  }
  
  html <- read_html (html)
  temp <- get_element (html, xpath = '//*[@id="quote-summary"]/div[1]/table/tbody/tr[1]/td[2]/span/text()', to_numeric = F)
  temp <- as.numeric (str_replace (temp, fixed (","), ""))
  previous_close <- temp
  if (anyNA (previous_close)) return (NA)
  
  change_close <- get_element (html, xpath = '//*[@id="quote-header-info"]/div[3]/div/div/span[2]', to_numeric = F)
  # change_close <- get_element (html, xpath = '//*[@id="quote-header-info"]/div[3]/div[1]/div/span[1]/text()', to_numeric = F)
  try (change_close <- as.numeric (substr (change_close, 1, strfind (change_close, " ") - 1)), silent = T)
  change_close <- as.numeric (change_close)
  if (anyNA (change_close)) return (NA)
  current_close <- round (previous_close + change_close, 2)
  if (anyNA (current_close)) return (NA)
  
  currency <- get_element (html, xpath = '//*[@id="quote-header-info"]/div[2]/div[1]', to_numeric = F)
  currency <- substr (currency, nchar (currency) - 2, nchar (currency))
  
  if (currency == "GBp") current_close <- round (current_close / 100, 2)
  
  return (current_close)
}

#----------------------------------------------------------------------------------------

get_stock_data <- function (id, symbol_naming = F, cache = T)
{
  if (nchar (id) == 12)
  {
    isin <- id
    symbol <- isin_to_symbol_yahoo (id)
  }
  else
  {
    isin <- symbol_to_isin (id)
    if (is.na (isin)) isin <- "NOT AVAILABLE"
    symbol <- id
  }
  
  if (symbol == "GDAXI") symbol <- "^GDAXI"
  
  suppressWarnings (rm (a))
  
  if (anyNA (symbol)) return (NA)
  
  check <- try (suppressWarnings (withTimeout (a <- getSymbols (symbol, src = "yahoo", auto.assign = F, warnings = F, verbose = F), timeout = 5)), silent = T)
  if (class (attributes (check)$condition)[1] == "TimeoutException")
  {
    Sys.sleep (1)
    return (get_stock_data (id = id, symbol_naming = symbol_naming, cache = cache))
  }
  
  if (!exists ("a")) return (NA)
  
  a <- na.omit (a)
  if (!symbol_naming)
  {
    colnames (a) <- c ("Open", "High", "Low", "Close", "Volume", "Adjusted")
  }
  else
  {
    colnames (a) <- c (symbol + "_Open", symbol + "_High", symbol + "_Low", symbol + "_Close", symbol + "_Volume", symbol + "_Adjusted")
    colnames (a) <- str_replace_all (colnames (a), fixed ("^"), "")
  }
  
  if (substr (isin, 1, stop = 2) == "GB")
  {
    spalten <- setdiff (colnames (a), c ("Volume", symbol + "_Volume"))
    a[, spalten] <- round (a[, spalten] / 100, 2)
  }
  
  return (a)
}

#----------------------------------------------------------------------------------------

id_to_name <- function (id)
{
  if (!exists ("isin_db")) load_isin_db()
  if (nchar (id) == 12)
  {
    isin <- id
    symbol <- isin_to_symbol (id)
  }
  else
  {
    isin <- symbol_to_isin (id)
    symbol <- id
  }
  result <- as.character (isin_db[which (isin_db$ISIN == isin), "Instrument"])
  if (length (result) == 0)
  {
    result <- as.character (isin_db2[which (isin_db2$ISIN == isin), "Instrument"])
  }
  if (length (result) == 0) result <- NA
  return (result)
}

#----------------------------------------------------------------------------------------

# Outputs Yahoo-Symbolcode
isin_to_symbol <- function (isin)
{
  if (!exists ("isin_db")) load_isin_db()
  symbol <- as.character (isin_db[which (isin_db$ISIN == isin)[1], "Mnemonic"])
  if (anyNA (symbol))
  {
    symbol <- as.character (isin_db2[which (isin_db2$ISIN == isin)[1], "Mnemonic"])
  }
  if (anyNA (symbol)) return (NA)
  erste_zwei <- substr (isin, 0, 2)
  if (isin %in% dax_isins) erste_zwei <- "DE"
  if (isin %in% mdax_isins) erste_zwei <- "DE"
  if (isin %in% sdax_isins) erste_zwei <- "DE"
  if (!identical (erste_zwei, "US")) symbol <- symbol + "." + erste_zwei
  return (symbol)
}

#----------------------------------------------------------------------------------------

isin_to_symbol_yahoo <- function (isin)
{
  if (!exists ("yahoo_cache"))
  {
    try (suppressWarnings (yahoo_cache <<- read.table ("C:\\Users/timme/Desktop/Forschungspraktikum/Momentum-Aktien-Scanner/finance db\\yahoo cache.csv", stringsAsFactors = F)), silent = T)
    if (!exists ("yahoo_cache")) yahoo_cache <<- data.frame (stringsAsFactors = F)
  }
  if ((identical (isin, NA)) | (identical (isin, NULL)))
  {
    yahoo_cache[isin, "value"] <<- NA
    write.table (yahoo_cache, "C:\\Users/timme/Desktop/Forschungspraktikum/Momentum-Aktien-Scanner/finance db\\yahoo cache.csv")
    return (NA)
  }
  if (isin %in% rownames (yahoo_cache))
  {
    return (yahoo_cache[isin, "value"])
  }
  server <- sample (c ("1", "2"), 1)
  server <- 1
  url <- "https://query" + server + ".finance.yahoo.com/v1/finance/search?q=" + isin + "&lang=en-US&region=US&quotesCount=6&newsCount=4&enableFuzzyQuery=false&quotesQueryId=tss_match_phrase_query&multiQuoteQueryId=multi_quote_single_token_query&newsQueryId=news_cie_vespa&enableCb=true&enableNavLinks=true&enableEnhancedTrivialQuery=false"
  html <- GET (url)
  #symbol <- strsplit (html, '"symbol\":\"')[[1]][2]
  #symbol <- strsplit (symbol, '"', fixed = T)[[1]][1]
  if (is.null (content (html)$quotes)) { browser(); return (NA) } # Error / Ban
  if (length (content (html)$quotes) == 0)
  {
    symbol <- NA
  }
  else
  {
    symbol <- content (html)$quotes[[1]]$symbol
  }
  yahoo_cache[isin, "value"] <<- symbol
  write.table (yahoo_cache, "C:\\Users/timme/Desktop/Forschungspraktikum/Momentum-Aktien-Scanner/finance db\\yahoo cache.csv")
  return (symbol)
}

#----------------------------------------------------------------------------------------

symbol_to_isin <- function (symbol)
{
  if (!exists ("isin_db")) load_isin_db()
  if (!is.character (symbol)) return (NA)
  p <- strfind (symbol, ".")
  if (!is.null (p)) symbol <- substr (symbol, 0, p - 1)
  isin <- as.character (isin_db[which (isin_db$Mnemonic == symbol)[1], "ISIN"])
  if (anyNA (isin))
  {
    isin <- as.character (isin_db2[which (isin_db2$Mnemonic == symbol)[1], "ISIN"])
  }
  return (isin)
}

#----------------------------------------------------------------------------------------

fill_ts <- function (x)
{
  for (c in 1:ncol (x))
  {
    nas <- which (is.na (x[, c]))
    for (n in nas)
    {
      if (n == 1) next
      x[n, c] <- x[n - 1, c]
    }
  }
  return (x)
}

#----------------------------------------------------------------------------------------

# Outer Join und keine TS
prepare_plot <- function (...)
{
  argg <- c (as.list (environment()), list(...))
  add_labels <- F
  if (class (argg[[1]])[1] == "character")
  {
    labels <- unlist (argg)
    add_labels <- T
  }
  
  m <- xts()
  for (i in 1:length (argg))
  {
    if (class (argg[[i]])[1] == "character")
    {
      argg[[i]] <- get_stock_data (argg[[i]])$Close
    }
    m <- merge (m, argg[[i]], join = "outer", fill = NA)
  }
  m <- fill_ts (m)
  
  if (add_labels) colnames (m) <- labels
  
  return (m)
}

#----------------------------------------------------------------------------------------

yield <- function (data)
{
  data <- as.numeric (data)
  return ((tail (data, 1) / head (data, 1)) - 1)
}

#----------------------------------------------------------------------------------------

max_yield <- function (data)
{
  data <- as.numeric (data)
  return ((max (data) / min (data)) - 1)
}

#----------------------------------------------------------------------------------------

running_yield <- function (data)
{
  result <- rollapply (data, 100, max_yield)
  return (result)
}

#----------------------------------------------------------------------------------------

running_relative_strength_rating <- function (data)
{
  result <- rollapply (data, 300, relative_strength_rating)
  return (result)
}

#----------------------------------------------------------------------------------------

relative_strength_rating <- function (data)
{
  monatsenden <- c()
  try (monatsenden <- tail (endpoints (data, on = "month", k = 1), 12), silent = T)
  if (length (monatsenden) != 12) 
  {
    return (NA)
  }
  teil_1 <- yield (data[monatsenden,][1:3])
  teil_2 <- yield (data[monatsenden,][4:6])
  teil_3 <- yield (data[monatsenden,][7:9])
  teil_4 <- yield (data[monatsenden,][10:12])
  return (teil_1 * 0.2 + teil_2 * 0.2 + teil_3 * 0.2 + teil_4 * 0.4)
}

#----------------------------------------------------------------------------------------

# Indicator = Function
rank_indicator <- function (data, functionname, ...)
{
  # Input array mit indaktoren
  # Output: Indikatoren ersetzen durch percentile
  # F�r jede Spalte runningfunction (combined[,1], "mean") berechnen
  # und ergebnis in neue matrix packen, dort am Ende ranken
  temp <- data.frame (matrix (nrow = nrow (data), ncol = ncol (data)))
  
  # Calculate Indicator Values
  for (i in 1:ncol (data))
  {
    temp[,i] <- lapply (X = data[,i], FUN = functionname, ...)
    temp[,i] <- rollapply (temp[,i], FUN = "median", width = 14)
  }
  
  # Rank them
  for (i in 1:nrow (temp))
  {
    temp[i,] <- round ((order (temp[i,], decreasing = T) / ncol (temp)) * 100, 0)
  }
  
  return (temp)
}

#----------------------------------------------------------------------------------------

suppressWarnings (rm (dax))
create_classifier_data <- function (id)
{
  if (nchar (id) == 12)
  {
    isin <- id
    symbol <- isin_to_symbol (id)
  }
  else
  {
    isin <- symbol_to_isin (id)
    symbol <- id
  }
  
  f <- grab_fundamentals (isin)
  if (anyNA (f)) return (NA)
  d <- data.frame (matrix (nrow = length (colnames (f$fundamentals)), ncol = 23))
  
  cols <- c ("Jahr",
             "Branche",
             "Sektor",
             "Ergebnis je Aktie (unverw�ssert)",
             "Umsatz je Aktie",
             "Buchwert je Aktie",
             "Cashflow je Aktie",
             "Dividende je Aktie",
             "KGV (Kurs/Gewinn)",
             "KUV (Kurs/Umsatz)",
             "KBV (Kurs/Buchwert)",
             "KCV (Kurs/Cashflow)",
             "Dividendenrendite in %",
             "Eigenkapitalrendite in %",
             "Umsatzrendite in %",
             "Gesamtkapitalrendite in %",
             "Ergebnis je Aktie (unverw�ssert) 1. Quartal (summiert)",
             "Ergebnis je Aktie (unverw�ssert) 2. Quartal (summiert)",
             "Ergebnis je Aktie (unverw�ssert) 3. Quartal (summiert)",
             "Ergebnis je Aktie (unverw�ssert) 4. Quartal (summiert)")
  
  colnames (d) <- c (cols, "class")
  
  for (i in 3:length (cols))
  {
    d[, i] <- as.numeric (f$fundamentals[cols[i],])
    if (cols[i] %in% c ("Umsatz je Aktie",
                        "Buchwert je Aktie",
                        "Cashflow je Aktie",
                        "Dividende je Aktie",
                        "Ergebnis je Aktie (unverw�ssert) 1. Quartal (summiert)",
                        "Ergebnis je Aktie (unverw�ssert) 2. Quartal (summiert)",
                        "Ergebnis je Aktie (unverw�ssert) 3. Quartal (summiert)",
                        "Ergebnis je Aktie (unverw�ssert) 4. Quartal (summiert)"))
    {
      # d[, i] <- round (d[, i] / d[, "Ergebnis je Aktie (unverw�ssert)"], 2)
    }
  }
  
  # Jahr
  d[, 1] <- colnames (f$fundamentals)
  
  # Branche
  d[, 2] <- f$information["Branche",]
  
  # Sektor
  d[, 3] <- f$information["Sektor",]
  
  raus <- c()
  for (i in 1:nrow (d))
  {
    if (as.numeric (d[i, "Jahr"]) < 2007) raus <- c (raus, i)
    if (length (which (is.na (as.numeric (d[i,])))) >= 10) raus <- c (raus, i)
  }
  d <- d[setdiff (1:nrow (d), raus),]
  
  # Class berechnen
  aktie <- get_stock_data (symbol)
  if (!exists ("dax")) dax <<- get_stock_data ("^GDAXI")
  for (i in 1:nrow (d))
  {
    benchmark <- prepare_plot (aktie, dax)
    benchmark <- benchmark[toString (as.numeric (d[i, "Jahr"]) + 1) + "/"]
    if (nrow (benchmark) == 0)
    {
      #d[i, "class"] <- NA
      next
    }
    # benchmark <- first (benchmark, "6 month")
    for (i2 in 1:ncol (benchmark))
    {
      benchmark[, i2] <- round (benchmark[, i2] / drop (coredata (benchmark[1, i2])) - 1, 2)
    }
    # Zielvariable = Maximale Outperformance des Vergleichswerts in den n�chsten 12 Monaten nach Ver�ffentlichung
    # hier max oder median?
    class <- median (first (benchmark[, "Close"] - benchmark[, "Close.1"], "1 year"))
    if (anyNA (class)) next
    d[i, "class"] <- class
  }
  return (d)
}

#----------------------------------------------------------------------------------------

schnellanalyse <- function (id, stop_on_cache_miss = F, ab_jahr = NA, recheck = F)
{
  data <- grab_fundamentals (id, stop_on_cache_miss = stop_on_cache_miss)
  if (!is.na (ab_jahr))
  {
    data$fundamentals <- data$fundamentals[, which (as.numeric (colnames (data$fundamentals)) >= ab_jahr)]
  }
  
  if (identical (data, NA)) return (NA)
  
  # kursdaten <- get_stock_data (id)
  # kurs <- as.numeric (tail (kursdaten$Close, 1))
  kurs <- get_stock_data_realtime (id)
  if (identical (kurs, NA)) return (NA)
  
  gewinne <- as.numeric (data$fundamentals["Ergebnis je Aktie (unverw�ssert)",])
  kgvs <- as.numeric (data$fundamentals["KGV (Kurs/Gewinn)",])
  kgv_median <- median (kgvs, na.rm = T)
  buchwerte <- as.numeric (data$fundamentals["KBV (Kurs/Buchwert)",])
  anzahl_jahre <- length (which (!is.na (gewinne)))
  
  if (anzahl_jahre < 5) return (NA)
  
  buchwerte_je_aktie <- as.numeric (data$fundamentals["Buchwert je Aktie",])
  gewinn_median <- min (median (gewinne, na.rm = T), median (tail (gewinne, 3), na.rm = T))
  buchwert_median <- median (buchwerte, na.rm = T)
  aktueller_buchwert <- buchwerte_je_aktie[tail (which (!is.na (buchwerte_je_aktie)), 1)]
  anzahl_aktien <- data$fundamentals["Mio. Aktien im Umlauf (splitbereinigt)",]
  anzahl_aktien <- as.numeric (anzahl_aktien[tail (which (!is.na (anzahl_aktien)), 1)] * 10^6)
  
  # Personalcheck
  mitarbeiter <- as.numeric (data$fundamentals["Personal am Ende des Jahres",])
  mitarbeiter <- mitarbeiter[which (!is.na (mitarbeiter))]
  mitarbeiter_proz <- round (tail (mitarbeiter, 1) / head (tail (mitarbeiter, 5), 1), 2)
  
  # Eigenkapitalquote
  eigenkapitalquote <- as.numeric (data$fundamentals["Eigenkapitalquote in %",])
  eigenkapitalquote <- round (tail (eigenkapitalquote[which (!is.na (eigenkapitalquote))], 1) / 100, 2)
  
  # Dividendenrendite
  dividenden <- as.numeric (data$fundamentals["Dividende je Aktie",])
  dividenden <- dividenden[which (!is.na (dividenden))]
  letzte_dividende <- tail (dividenden, 1)
  if (length (letzte_dividende) == 0) letzte_dividende <- 0
  dividendenrendite <- round (letzte_dividende / kurs, 2)
  
  marktkapitalisierung <- round (anzahl_aktien * kurs, 2)
  dividendenjahre <- length (which (!is.na (data$fundamentals["Dividende je Aktie",])))
  gewinnjahre <-length (which (gewinne > 0))
  
  if (marktkapitalisierung < 100 * 10^6) return (NA)
  
  # trend <- runningfunction (kursdaten$Close, "mean", 200)
  # Es soll nur eine kurze "Negativphase" geben, davor aber alles gut gewesen sein
  # trend <- as.numeric (head (tail (trend, 90), 1))
  # kurs_alt <- as.numeric (head (tail (kursdaten$Close, 90), 1))
  
  bewertung_gewinne <- sum (rep (gewinn_median * 0.5, 20) * 1.03^-(1:20))
  if (buchwert_median < 0) { bewertung_buchwert <- 0 } else { bewertung_buchwert <- buchwert_median * aktueller_buchwert }
  bewertung_kgv <- gewinn_median * kgv_median
  
  result <- list()
  #result$name <- id_to_name (id)
  result$analyse_startjahr <- round (as.numeric (colnames (data$fundamentals))[1], 0)
  result$anzahl_jahre <- anzahl_jahre
  result$gewinnjahre <- gewinnjahre
  result$dividendenjahre <- dividendenjahre
  result$dividendenrendite <- dividendenrendite
  result$marktkapitalisierung_mio <- round (marktkapitalisierung / 10^6, 2)
  result$eigenkapitalquote <- eigenkapitalquote
  result$mitarbeiter_proz <- mitarbeiter_proz
  #if (kurs_alt < trend) { result$trend_vorher <- -1 } else { result$trend_vorher <- 1 }
  result$gewinn_median <- round (gewinn_median, 2)
  result$buchwert_median <- round (buchwert_median, 2)
  result$kgv_median <- kgv_median
  result$aktueller_buchwert <- round (aktueller_buchwert, 2)
  result$bewertung_buchwert <- round (bewertung_buchwert, 2)
  result$bewertung_gewinne <- round (bewertung_gewinne, 2)
  result$bewertung_kgv <- round (bewertung_kgv, 2)
  
  bewertungen <- c (bewertung_gewinne, bewertung_buchwert, bewertung_kgv)
  #bewertungen <- bewertungen[which (bewertungen > 0)]
  
  result$bewertung_gewinn_buchwert_kgv <- round (min (bewertungen), 2)
  result$aktueller_kurs <- kurs
  result$einstiegspreis <- round (result$bewertung_gewinn_buchwert * 0.7, 2)
  result$einstiegspreis_quote <- round (kurs / result$einstiegspreis, 2)
  
  result_df <- data.frame (unlist (result), stringsAsFactors = F)
  colnames (result_df) <- ""
  rownames (result_df) <- names (result)
  
  if ((data$information["Sektor",] == "Finanzsektor")
      & (identical (ab_jahr, NA))
      & (recheck == F))
  {
    check <- schnellanalyse (id = id, stop_on_cache_miss = stop_on_cache_miss, ab_jahr = 2008, recheck = T)
    if (check["einstiegspreis_quote",] > result_df["einstiegspreis_quote",]) return (check)
  }
  
  return (result_df)
}

#----------------------------------------------------------------------------------------

#stop ("DONE")

# #liste <- c (symbol_to_isin ("LIN.DE"), symbol_to_isin ("BMW.DE"))
# liste <- c (dax_isins, mdax_isins, sdax_isins)
# 
# if ((!exists ("isin_db")) | (!exists ("isin_db2"))) load_isin_db()
# liste <- as.character (isin_db[which ((isin_db$MIC.Code == "XETR")
#                                       & ((isin_db$Product.Assignment.Group.Description != "EXCHANGE TRADED FUNDS - RENTEN")
#                                       & (isin_db$Product.Assignment.Group.Description != "EXCHANGE TRADED FUNDS - PASSIV")
#                                       & (isin_db$Product.Assignment.Group.Description != "EXCHANGE TRADED FUNDS - AKTIV"))),]$ISIN)
# liste <- unique (c (liste, as.character (isin_db2$ISIN)))
# 
# result <- data.frame (stringsAsFactors = F)
# names <- c()
# isins <- c()
# for (i in 1:length (liste))
# {
#   temp <- NA
#   try (temp <- schnellanalyse (liste[i], stop_on_cache_miss = T), silent = T)
#   if (!identical (temp, NA))
#   {
#     if (identical (temp["einstiegspreis_quote", 1], NA)) next
#     if (nrow (result) > 0) result <- result[,3:ncol (result)]
#     result <- rbind (result, t (temp), stringsAsFactors = F)
#     isins <- c (isins, liste[i])
#     result <- cbind (isins, result, stringsAsFactors = F)
#     colnames (result)[1] <- "isin"
#     names <- c (names, id_to_name (liste[i]))
#     result <- cbind (names, result, stringsAsFactors = F)
#     colnames (result)[1] <- "name"
#     quote <- temp["einstiegspreis_quote", 1]
#   }
#   else
#   {
#     quote <- NA
#   }
#   print (liste[i] + " : " + id_to_name (liste[i]) + " : " + quote + " [" + toString (i) + "/" + toString (length (liste)) + "]")
#   # if (nrow (result) > 20) break
# }
# 
# result <- cbind (result[, 1:2], result[, ncol (result)], result[, 3:ncol (result)], stringsAsFactors = F)
# colnames (result)[3] <- "einstiegspreis_quote"
# result[, 3] <- as.numeric (as.character (result[, 3])) # Factor -> Numeric
# 
# #steigt <- which (result$trend_vorher == 1)
# #faellt <- which (result$trend_vorher == -1)
# #result$trend_vorher[steigt] <- "steigt"
# #result$trend_vorher[faellt] <- "f�llt"
# 
# result <- result[which (!is.na (result$einstiegspreis_quote)),]
# result <- result[which ((result$einstiegspreis_quote > 0) & (result$einstiegspreis_quote <= 2)),]
# 
# write.table (result, "c:\\a\\result.csv", sep = "@", eol = "\n", quote = F, row.names = F, col.names = T, na = "")
# 
# View (result)

# stop ("DONE")
# 
# 
# result <- c()
# for (i in 1:length (liste))
# {
#   print (isin_to_symbol (liste[i]) + " - " + toString (i) + "/" + length (liste))
#   temp <- create_classifier_data (liste[i])
#   if (identical (temp, NA)) next
#   result <- rbind (result, temp)
# }
# 
# result <- result[which (!is.na (result$class)),]
# 
# backup_result <- result
# 
# q <- quantile (result$class, probs = c (0.1, 0.9))
# all <- 1:nrow (result)
# all <- setdiff(all, which (result$class <= q[[1]]))
# all <- setdiff(all, which (result$class >= q[[2]]))
# temp <- result$class
# #result[which (temp <= q[[1]]), "class"] <- "Underperformer"
# #result[which (temp >= q[[2]]), "class"] <- "Outperformer"
# #result[all, "class"] <- "Mittelfeld"
# 
# # Random-test
# result_random <- result
# for (i in 1:(ncol (result) - 4))
# {
#   result_random[, i] <- sample (1:10, size = nrow (result_random), replace = T)
# }
# 
# write.table (result, "c:\\a\\fundamental_classifier.csv", sep = ",", eol = "\n", quote = F, row.names = F, col.names = T, na = "")
# write.table (backup_result, "c:\\a\\fundamental_classifier_backup.csv", sep = ",", eol = "\n", quote = F, row.names = F, col.names = T, na = "")
# write.table (result_random, "c:\\a\\fundamental_classifier_random.csv", sep = ",", eol = "\n", quote = F, row.names = F, col.names = T, na = "")
# 
# # filter <- sqldf ('SELECT * FROM result WHERE einstiegspreis_quote <= 1 AND mitarbeiter_proz > 1 AND trend_vorher = "steigt" ORDER BY einstiegspreis_quote ASC'); View (filter)
