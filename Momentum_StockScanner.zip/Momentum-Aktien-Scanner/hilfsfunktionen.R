# F�r unter anderem "index"
library (zoo)

#------------------------------------------------------------

grab_url <- function (url, tries = 0, maxtries = 0, silent = T, file = F)
{
  if ((identical (url, NA)) | (identical (url, NULL))) return (FALSE)
  
  if (tries > 2)
  {
    return (FALSE)
  }
  
  tmp <- tempfile()
  url <- c (toString (url)) # Wieso muss das rein?
  if (silent == F) print ("url: *" + url + "*")

  check <- try (suppressWarnings (download.file (url, destfile = tmp, quiet = T, headers = c ("User-Agent" = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:87.0) Gecko/20100101 Firefox/87.0"))), silent = T)
  if (file) return (tmp)
  if (inherits (check, "try-error"))
  {
    unlink (tmp)
    if (tries >= maxtries) return (NA)
    # cat ("Grab url error on: " + url + " (tries = " + toString (tries) + ")\r\n")
    return (grab_url (url = url, tries = tries + 1))
  }
  
  connection <- file (tmp, "rb")
  html <- readChar (tmp, file.info(tmp)$size)
  close (connection)
  unlink (tmp)
  
  return (html)
}

#------------------------------------------------------------

# Eigenes Seasonal berechnen: Evtl als Eingabewert.
our_seasonal <- function (data)
{
  seasons <- data.frame(matrix (nrow = 0, ncol = 3))
  temp <- data.frame (data, rep (1:12, 1000)[1: length (data)])
  colnames (temp) <- c ("quotient", "season")
  for (season in 1:12)
  {
    dummy <- temp[which ((temp$season == season) & !is.na (temp$quotient)), "quotient"]
    seasons <- rbind (seasons, c (season, mean (dummy), sd (dummy)))
  }
  colnames (seasons) <- c ("season", "mean", "sd")
  return (seasons)
}

#------------------------------------------------------------

list_to_matrix <- function (list)
{
  if (length(list) == 0) return (c())
  maxlen <- 0
  for (i in 1:length(list))
  {
    if (length (list[[i]]) > maxlen)
    {
      maxlen <- length(list[[i]])
    }
  }
  result <- matrix(data = 0, nrow = length(list), ncol = maxlen)
  for (i in 1:length(list))
  {
    result[i,] <- list[[i]]
  }
  return(result)
}

#------------------------------------------------------------

getwindows <- function (data, windowsize = 10, start = 1)
{
  if (start != 1) stop ("Start != 1 noch nicht implementiert!")
  if (length (data) == 0) return (c())

  if (is.vector(data) | ("xts" %in% class (data)))
  {
    maxlen <- length (data)
  }
  else
  {
    maxlen <- dim (data)[1]
    maxwidth <- dim (data)[2]
  }
  
  lagpad <- function(x, k)
  {
    c(rep(NA, k), x)[1 : length(x)]
  }
  
  # ---------------------------------------  
  vector_windows <- function (data)
  {
    temp <- matrix (data = 0, nrow = windowsize, ncol = maxlen)   
    for (i in 1:windowsize)
    {
      if (i == 1)
      {
        temp[i,] <- data
      }
      else
      {
        temp[i,] <- lagpad (temp[i-1,], 1)
      }    
    }
    temp <- temp[windowsize:1,]
    if (windowsize > 1)
    {
      windows <- split(temp, rep(1:ncol(temp), each = nrow(temp)))
    }
    else
    {
      windows <- as.list (temp)
      names (windows) <- 1:maxlen
    }
    return (windows)
  }
  # ---------------------------------------
  vector_windows_string <- function (data)
  {
    temp <- matrix (data = 0, nrow = windowsize, ncol = maxlen)
    for (i in 1:windowsize)
    {
      if (i == 1)
      {
        temp[i,] <- 1:maxlen
      }
      else
      {
        temp[i,] <- lagpad (temp[i-1,], 1)
      }
    }
    temp <- temp[windowsize:1,]
    windows <- split(temp, rep(1:ncol(temp), each = nrow(temp)))
    newline <- rep (data[1], times <- windowsize)
    newline[1:windowsize] <- NA
    for (i in 1:maxlen)
    {
      not_na <- which (!is.na (windows[[i]]))
      indices <- windows[[i]][not_na]
      windows[[i]] <- newline
      windows[[i]][not_na] <- data[indices]
    }
    return (windows)
  }
  # ---------------------------------------
  
  if (is.vector(data) | ("xts" %in% class (data)))
  {
    windows <- vector_windows(data)
  }
  else
  {
    windows <- vector(mode = "list", length = maxlen)
    newmatrix <- matrix (data = NA, nrow = windowsize, ncol = maxwidth)
    colnames (newmatrix) <- colnames (data)
    rownames (newmatrix) <- rownames(data)[1:windowsize]
    newframe <- head (data, windowsize)
    for (i in 1:maxlen)
    {
      if (is.matrix (data))
      {
        windows[[i]] <- newmatrix
      }
      else
      {
        windows[[i]] <- newframe
      }
    }
    
    for (col in 1:maxwidth)
    {
      if (is.numeric (data[,col]))
      {
        w <- vector_windows (data[,col])
        for (i in 1:length(w))
        {
          windows[[i]][,col] <- w[[i]]
        }
      }
      else
      {
        w <- vector_windows_string (data[,col])
        for (i in 1:length(w))
        {
          windows[[i]][,col] <- as.data.frame (w[[i]])
        }
      }
    }
  }
  
  return (windows)
}

#------------------------------------------------------------

runningfunction <- function (data, functionname = "mean", windowsize = 10, start = 1, raw_output = F, ...)
{
  if (is.vector(data) | ("xts" %in% class (data)))
  {
    maxlen <- length(data)
  }
  else
  {
    maxlen <- dim(data)[1]
  }

  windows <- getwindows (data = data, windowsize = windowsize, start = start)
  nas <- which (is.na (windows))
  not_nas <- subset (windows, !is.element (index (windows), nas))
  gueltig <- head (not_nas, 1)
  
  if (length (not_nas) > 0) windows[nas] <- gueltig  
  if (length (gueltig) == 0)
  {
    gueltig <- NA
  }
  else
  {
    gueltig <- gueltig[[1]]
  }
  
  # Use cluster or cache?
  cache <- F
  cluster <- F
  
  # cat ("*** runningfunction *** " + functionname + " - cache: " + toString (cache) + " - cluster: " + toString (cluster) + "\r\n")
  
  result <- lapply (X = windows, FUN = functionname, ...)
  result[nas] <- NA
  
  if (raw_output == T)
  {
    result <- result
  }
  else if (is.vector (data))
  {
    result <- as.vector (list_to_matrix (result))
  }
  else
  {
    result <- list_to_matrix (result)
  }
  
  return (result)
}

#------------------------------------------------------------

discretize <- function (data, classes = 10, numeric = FALSE, classmeans = T)
{
  if (classes < 2) classes <- 2
  if (is.factor (data))
  {
    data <- as.numeric (levels(data))[data]
  }
  
  data_original <- data
  non_nas <- c()
  if (length (which (is.na (data))) > 0)
  {
    non_nas <- which (!is.na (data))
    data <- data[non_nas]
  }
  
  data_new <- data
  quantiles <- quantile (data, (1:(classes - 1))/classes)
  from <- "-Inf"
  old_indices <- c()
  for (q in 1:(length (quantiles) + 1))
  {
    if (q <= length (quantiles))
    {
      to <- toString (round (quantiles[q], 4))
      indices <- which (data <= quantiles[q])
    }
    else
    {
      to <- "Inf"
      indices <- 1:length (data)
    }
    indices <- setdiff (indices, old_indices)
    if (classmeans == TRUE)
    {
      if (from == "-Inf")
        data_new[indices] <- round (as.numeric (to), 3)
      else if (to == "Inf")
        data_new[indices] <- round (as.numeric (from), 3)
      else
        data_new[indices] <- round ((as.numeric (from) + as.numeric (to)) / 2, 3)
    }
    else if (numeric == FALSE)
    {
      data_new[indices] <- "[" + from + " - " + to + "]"
    }
    else
    {
      data_new[indices] <- q
    }
    old_indices <- c (old_indices, indices)
    from <- to
  }
  
  if (length (non_nas) > 0)
  {
    data_original[non_nas] <- data_new
    data_new <- data_original
  }
  
  result <- data_new

  return (result)
}

