library (eRic)

library (ggrepel)

#WPM ("refresh-cache")
#WPM ("list-packages", "available")
#WPM ("install-package", "hotSpot")

#install.packages("remotes")
#remotes::install_github("etlundquist/eRic")

#------------------------------------------------------------------------------------------------------------

price_touched <- function (what, limit = 10)
{
  counts <- c()
  for (i in 1:nrow (what))
  {
    start <- max (i - 60, 1)
    count <- length (which (abs (as.numeric (what[start:(i - 1)]) - as.numeric (what[i])) <= limit))
    counts <- c (counts, count)
  }
  return (counts)
}

#------------------------------------------------------------------------------------------------------------

cut <- function (what) 
{  
  # Abschneiden?
  p <- which (strfind (what, fixed (" ")) <= 3)
  if (length (p) > 0)
  {
    p <- max (p)
    line <- substr (what, p + 1, nchar (what))
  }
  else
  {
    line <- what
  }  
  return (line)
}

# ----------------------------------------------------------------------------------------------

count_cuts <- function (what) 
{
  if (is.na (what)) return (0)
  line <- what
  cuts <- 0
  repeat
  {
    vorher <- line
    line <- cut (line)
    if (vorher != line) cuts <- cuts + 1
    # Rekursionszeichen weg
    if (substr (line, 1, 1) == "|")
    {
      line <- substr (line, 2, nchar (line))
    }
    else
    {
      break
    }
  }
  return (cuts)
}

# ----------------------------------------------------------------------------------------------

make_r_function <- function (model, model_array = c(), level = 1)
{
  # Model -> String
  if (level == 1)
  {
    model_string <- rJava::.jstrVal (model$associator)
    temp <- str_split (model_string, fixed ("\n"))[[1]]
    start <- which (temp == "")[which (which (temp == "") > 1)][1]
    model_array <- temp[(start + 1):(length (temp) - 1)]
  }
  
  # Abschneiden?
  line <- model_array[level]
  cuts <- 0
  repeat
  {
    vorher <- line
    line <- cut (line)
    if (vorher != line) cuts <- cuts + 1
    # Rekursionszeichen weg
    if (substr (line, 1, 1) == "|")
    {
      line <- substr (line, 2, nchar (line))
    }
    else
    {
      break
    }
  }
  
  command <- line
  
  # Fix Operator
  gr <- strfind (line, ">")
  kl <- strfind (line, "<")
  if (is.null (gr) & is.null (kl))
  {
    line <- str_replace_all (line, fixed (" = "), "=")
    command <- str_replace_all (line, fixed ("="), " == ")
  }
  
  # Parse Command
  parsed <- strsplit (command, fixed (" "))[[1]]
  variable <- parsed[1]
  operator <- parsed[2]
  vergleich <- parsed[3]
  zaehler <- as.numeric (str_extract (parsed[5], regex ("\\d+")))
  temp_nenner <- str_extract (parsed[5], regex ("\\/\\d+"))
  nenner <- as.numeric (substr (temp_nenner, 2, nchar (temp_nenner)))
  quote <- round (zaehler / nenner, 2)
  
  # Build R Code
  if (level == 1)
  {
    #r_code <- '   ' + 'quoten <- c (' + quote + ')\r\n' + make_r_function (model = model, model_array = model_array, level = level + 1)
    r_code <- '   ' + 'quoten <- c()\r\n' + make_r_function (model = model, model_array = model_array, level = level + 1)
  }
  else
  {
    if (!is.na (suppressWarnings (as.numeric (vergleich))))
    {
      temp_vergleich <- vergleich
    }
    else
    {
      temp_vergleich <- '"' + vergleich + '"'
    }
    if (level > 2)
    {
      whitespaces <- "   " + paste (replicate ((cuts - 1) * 3, " "), collapse = "")
    }
    else
    {
      whitespaces <- "   "
    }
    
    # Wo ist die nächste Zeile auf selber Ebene?
    new_cuts <- count_cuts (model_array[level + 1])
    next_same_cuts <- 0
    for (i in (level + 1):length (model_array))
    {
      if (is.na (model_array[i])) break
      counted_cuts <- count_cuts (model_array[i])
      if (counted_cuts < cuts)
      {
        break
      }
      if (counted_cuts == cuts)
      {
        next_same_cuts <- i
        break
      }
    }
    
    # Nicht selbe Ebene: Wir müssen einrücken und Elemente auf gleicher Ebene suchen
    if (new_cuts > cuts)
    {
      if (next_same_cuts > 0)
      {
        r_code_insert <- '\r\n' + make_r_function (model = model, model_array = model_array, level = next_same_cuts)
      }
      else
      {
        r_code_insert <- ''
      }
      r_code <- whitespaces + 'if (D$' + variable + ' ' + operator + ' ' + temp_vergleich + ')\r\n' + whitespaces + '{\r\n' + whitespaces + '   quoten <- c (quoten, ' + quote + ')\r\n' + make_r_function (model = model, model_array = model_array, level = level + 1) + '\r\n' + whitespaces + '}'  + r_code_insert
    }
    # Selbe Ebene: Nicht einrücken
    else if (new_cuts == cuts)
    {
      r_code <- whitespaces + 'if (D$' + variable + ' ' + operator + ' ' + temp_vergleich + ')\r\n' + whitespaces + '{\r\n' + whitespaces + '   quoten <- c (quoten, ' + quote + ')\r\n' + whitespaces + '}\r\n' + make_r_function (model = model, model_array = model_array, level = level + 1)
    }
    # Kleinere Ebene: Rekursion Beenden
    else if (new_cuts < cuts)
    {
      r_code <- whitespaces + 'if (D$' + variable + ' ' + operator + ' ' + temp_vergleich + ')\r\n' + whitespaces + '{\r\n' + whitespaces + '   quoten <- c (quoten, ' + quote + ')\r\n' + whitespaces + '}'
    }
  }
  
  if (level == 1)
  {
    r_code <- 'assoc_classify <- function (D)\r\n' + 
              '{\r\n' + 
              r_code + '\r\n' + 
              '   if (length (quoten) == 0) quoten <- c (' + quote + ')\r\n' + 
              '   return (max (quoten))\r\n' + 
              '}\r\n'
    r_code <- str_replace_all (r_code, "\r\n", "\n")
    eval (parse (text = r_code))
    return (assoc_classify)
  }
  
  return (r_code)
}

#------------------------------------------------------------------------------------------------------------

will_turn <- function (what, window = 24, stop = 3)
{
  result <- c()
  for (i in 1:length (what))
  {
    if (anyNA (what[i]))
    {
      result <- c (result, NA)
      next
    }
    checkwindow <- i + 0:window
    checkwindow <- checkwindow[which (checkwindow <= length (what))]
    if (what[i] >= 0)
    {
      stop_hit <- which (what[checkwindow] >= what[i] + stop)
    }
    else
    {
      stop_hit <- which (what[checkwindow] <= what[i] - stop)
    }
    if (length (stop_hit) == 0)
    {
      result <- c (result, "win")
    }
    else
    {
      result <- c (result, "loss")
    }
  }
  return (as.factor (result))
}

#------------------------------------------------------------------------------------------------------------

differences <- function (what)
{
  n <- 1
  result <- data.frame (matrix (nrow = nrow (what), ncol = ncol (what) * 2))
  for (i in 1:ncol (what))
  {
    for (y in 1:ncol (what))
    {
      result[, n] <- what[, i] - what[, y]
      colnames (result)[n] <- toString (i) + "-" + toString (y)
      n <- n + 1
    }
  }
  return (result)
}

#------------------------------------------------------------------------------------------------------------

ignore_last_median <- function (what)
{
  return (median (what[1:(length (what) - 1)]))
}

#------------------------------------------------------------------------------------------------------------

maxvalues <- function (what)
{
  for (i in 1:nrow (what))
  {
    diff_up <- what[i, "High"] - what[i, "Open"]
    diff_down <- what[i, "Open"] - what[i, "Low"]
    if (diff_up > diff_down)
    {
      what[i, "Close"] <- what[i, "High"]
    }
    else
    {
      what[i, "Close"] <- what[i, "Low"]
    }
  }
  return (what)
}

#------------------------------------------------------------------------------------------------------------

pchange <- function (what)
{
  for (i in 1:ncol (what))
  {
    what[, i] <- as.numeric (what[, i]) / as.numeric (what[1, i])
  }
  return (what)
}

#------------------------------------------------------------------------------------------------------------

mplot <- function (a, pos = NA, labels = NA, title = NA, colors = NA)
{
  switch_plus (FALSE)
  
  if (identical (title, NA))
    title <- "Subplot"
  
  if (identical (pos, NA))
    pos <- rep (0, ncol (a))

  if (identical (labels, NA))
    labels <- rep ("", nrow (a))

  p1 <- ggplot (a, aes (x = index (a), y = a[, max (head (which (pos == 0), 1), 1)]))
  p2 <- ggplot (a, aes (x = index (a), y = a[, max (head (which (pos > 0), 1), 1)]))
  
  if (identical (colors, NA))
    colors <- c ("Red", "Blue", "Black", "Green", "Brown", "Yellow")
  
  for (i in 1:ncol (a))
  {
    if (pos[i] == 0)
    {
      p1 <- p1 + geom_line (aes_string (y = names (a)[i]), size = 1, colour = colors[i])
    }
    else
    {
      p2 <- p2 + geom_line (aes_string (y = names (a)[i]), size = 1, colour = colors[i])
    }
  }

  p1 <- p1 + geom_label_repel (aes (label = labels), color = "Blue", box.padding = 1, min.segment.length = 0, size = 2)
  p1 <- p1 + labs (title = title, y = colnames (a)[max (head (which (pos == 0), 1), 1)], x = "")
  p1 <- p1 + theme_tq()
  
  p2 <- p2 + labs (y = colnames (a)[max (head (which (pos > 0), 1), 1)], x = "")
  p2 <- p2 + theme_tq()

  if (length (which (pos > 0)) > 0)
  {
    result <- suppressWarnings (plot (plot_grid (p1, p2, align = "v", nrow = 2, rel_heights = c(3/4, 1/4))))
  }
  else
  {
    result <- suppressWarnings (plot (p1))
  }

  switch_plus (TRUE)
  return (result)
}

#------------------------------------------------------------------------------------------------------------

# stop ("done")
# 
# x1 <- grab_ig ("IX.D.DAX.IFMM.IP", from = "01.04.2020")
# x2 <- grab_ig ("IX.D.SPTRD.IFE.IP", from = "01.04.2020")
# x3 <- grab_ig ("IX.D.FTSE.IFE.IP", from = "01.04.2020")
# x4 <- grab_ig ("CS.D.CFEGOLD.CFE.IP", from = "01.04.2020")
# x5 <- grab_ig ("CC.D.VIX.UME.IP", from = "01.04.2020")
# 
# x1 <- maxvalues (x1)
# x2 <- maxvalues (x2)
# x3 <- maxvalues (x3)
# x4 <- maxvalues (x4)
# x5 <- maxvalues (x5)
# 
# #x1 <- pchange (x1)
# #x2 <- pchange (x2)
# #x3 <- pchange (x3)
# #x4 <- pchange (x4)
# #x5 <- pchange (x5)
# 
# #x1$ma <- runningfunction (x1$Close, functionname = "ignore_last_median", windowsize = 12)
# #x2$ma <- runningfunction (x2$Close, functionname = "ignore_last_median", windowsize = 12)
# #x3$ma <- runningfunction (x3$Close, functionname = "ignore_last_median", windowsize = 12)
# #x4$ma <- runningfunction (x4$Close, functionname = "ignore_last_median", windowsize = 12)
# #x5$ma <- runningfunction (x5$Close, functionname = "ignore_last_median", windowsize = 12)
# 
# #x1$mdm <- runningfunction (x1$Close - x2$Close, functionname = "max_div_min", windowsize = 12)
# #x2$mdm <- runningfunction (x2$Close, functionname = "max_div_min", windowsize = 12)
# #x3$mdm <- runningfunction (x3$Close, functionname = "max_div_min", windowsize = 12)
# #x4$mdm <- runningfunction (x4$Close, functionname = "max_div_min", windowsize = 12)
# #x5$mdm <- runningfunction (x5$Close, functionname = "max_div_min", windowsize = 12)
# 
# #x1$diff <- diff (x1$Close)
# #x2$diff <- diff (x2$Close)
# #x3$diff <- diff (x3$Close)
# #x4$diff <- diff (x4$Close)
# #x5$diff <- diff (x5$Close)
# 
# #x1$ma_diff <- x1$Close - x1$ma
# #x2$ma_diff <- x2$Close - x2$ma
# #x3$ma_diff <- x3$Close - x3$ma
# #x4$ma_diff <- x4$Close - x4$ma
# #x5$ma_diff <- x5$Close - x5$ma
# 
# combined <- prepare_plot (x1, x2, x3, x4, x5)
# 
# #combined$class <- combined$ma_diff
# 
# #bleibt <- which (!is.na (combined$ma))
# #combined <- combined[bleibt,]
# combined$day <- day (combined)
# combined$hour <- hour (combined)
# combined$minute <- minute (combined)
# 
# #diffs <- differences (combined[, c ("diff.1", "diff.2", "diff.3", "diff.4", "mdm.1", "mdm.2", "mdm.3", "mdm.4")])
# #diffs <- as.xts (diffs, order.by = index (combined))
# #neue_namen <- c (colnames (combined), colnames (diffs))
# #combined <- cbind (combined, diffs)
# #colnames (combined) <- neue_namen
# 
# #train <- xts (data.frame (combined$minute, combined$hour, diffs, combined$ma_diff), order.by = index (combined))
# 
# #write.arff (combined[, c("ma_diff", "ma_diff.1", "ma_diff.2", "class")], "c:\\a\\test.arff")
# 
# #model <- make_Weka_classifier ("weka/classifiers/functions/LinearRegression")
# #model <- make_Weka_classifier ("weka/classifiers/trees/RandomForest")
# 
# #darf_rein <- which (day (train) != 8)
# 
# # na.fail oder na.omit
# #fit <- model (as.formula ("diff ~ ."), data = data.frame (train[darf_rein,]), control = c(), na.action = "na.omit")
# 
# #cal <- prCalibrate (r.calib = as.numeric (train$turn) - 1, p.calib = train$quote)$cal.probs
# #combined$quote <- cal
# 
# #combined$prediction <- lag (combined$Close, 1) + predict (fit, train)
# #combined$prediction <- combined$ma + predict (fit, train)
# 
# #combined$dax_snp <- combined$ma_diff - combined$ma_diff.1
# 
# #plot (x1$ma_diff)
# #plot (x2$ma_diff)
# #plot (x3$ma_diff)
# 
# #multiplot (prepare_plot (combined$mdm)["2020-04-07"], F)
# 
# combined$test1 <- combined$Close - combined$Close.1
# combined$test1 <- combined$test1 - runningfunction (combined$test1, functionname = "median", windowsize = 12)
# #combined$test1 <- runningfunction (combined$test1, functionname = "normalize", windowsize = 72)
# combined$test1_lag <- lag (combined$test1, 1)
# combined$test1_lag2 <- lag (combined$test1, 2)
# combined$test1_lag3 <- lag (combined$test1, 3)
# combined$test1_lag4 <- lag (combined$test1, 4)
# combined$test1_sd <- runningfunction (combined$test1, functionname = "sd", windowsize = 12)
# combined$weg_50 <- combined$Close %% 50
# combined$weg_100 <- combined$Close %% 100
# 
# combined$test2 <- combined$Close - combined$Close.2
# combined$test2 <- combined$test2 - runningfunction (combined$test2, functionname = "median", windowsize = 12)
# #combined$test2 <- runningfunction (combined$test2, functionname = "normalize", windowsize = 72)
# combined$test2_lag <- lag (combined$test2, 1)
# combined$test2_lag2 <- lag (combined$test2, 2)
# combined$test2_lag3 <- lag (combined$test2, 3)
# combined$test2_lag4 <- lag (combined$test2, 4)
# combined$test2_sd <- runningfunction (combined$test2, functionname = "sd", windowsize = 12)
# 
# combined$test3 <- combined$Close - combined$Close.3
# combined$test3 <- combined$test3 - runningfunction (combined$test3, functionname = "median", windowsize = 12)
# #combined$test3 <- runningfunction (combined$test3, functionname = "normalize", windowsize = 72)
# combined$test3_lag <- lag (combined$test3, 1)
# combined$test3_lag2 <- lag (combined$test3, 2)
# combined$test3_lag3 <- lag (combined$test3, 3)
# combined$test3_lag4 <- lag (combined$test3, 4)
# combined$test3_sd <- runningfunction (combined$test3, functionname = "sd", windowsize = 12)
# 
# combined$test4 <- combined$Close - combined$Close.4
# combined$test4 <- combined$test4 - runningfunction (combined$test4, functionname = "median", windowsize = 12)
# #combined$test4 <- runningfunction (combined$test4, functionname = "normalize", windowsize = 72)
# combined$test4_lag <- lag (combined$test4, 1)
# combined$test4_lag2 <- lag (combined$test4, 2)
# combined$test4_lag3 <- lag (combined$test4, 3)
# combined$test4_lag4 <- lag (combined$test4, 4)
# combined$test4_sd <- runningfunction (combined$test3, functionname = "sd", windowsize = 12)
# 
# combined <- combined [which (!is.na (combined$test1)),]
# 
# combined$profits <- round (trend_analysis (combined, stop = 12, lookahead = 36)$trend_profit, 2)
# 
# #mplot (prepare_plot (combined$Close, combined$test)["2020-04-08"], pos = c(0, 1))
# 
# #mplot (prepare_plot (combined$mdm, combined$mdm.1)["2020-04-08"])
# 
# #combined$touched <- price_touched (combined$Close, 10)
# combined$diff_Close <- diff (combined$Close)
# 
# train <- combined
# train <- data.frame (train, stringsAsFactors = F)
# train$turn <- will_turn (as.numeric (train$test1))
# 
# #darf_rein <- which ((day (combined) != 13) & (abs (train$test1) >= 50))
# #darf_rein <- which ((day (combined) != 13) & (abs (train$test1) >= 50))
# darf_rein <- which ((abs (train$test1) >= 50))
# 
# #, na.action = "na.omit"
# #fit <- model (as.formula ("turn ~ test1 + test1_lag + test1_lag2 + test1_lag3 + test1_lag4 +
# #                                + test2 + test2_lag + test2_lag2 + test2_lag3 + test2_lag4 +
# #                                + test3 + test3_lag + test3_lag2 + test3_lag3 + test3_lag4 +
# #                                + test4 + test4_lag + test4_lag2 + test4_lag3 + test4_lag4 +
# #                                + hour + minute"), data = data.frame (train[darf_rein,]), control = c())
# 
# #quote <- predict (fit, combined, type = "probability")
# 
# stop ("done")
# 
# model <- make_Weka_associator ("weka/associations/HotSpot")
# 
# new_model <- model (x = train[darf_rein, c("test1", "test1_lag", "test1_lag2", "test1_lag3", "test1_lag4",
#                                            "test2", "test2_lag", "test2_lag2", "test2_lag3", "test2_lag4",
#                                            "test3", "test3_lag", "test3_lag2", "test3_lag3", "test3_lag4",
#                                            "test4", "test4_lag", "test4_lag2", "test4_lag3", "test4_lag4",
#                                            #"Volume.1", "Volume.2", "Volume.3", "Volume.4",
#                                            #"test1_sd", "test2_sd", "test3_sd", "test4_sd",
#                                            #"weg_50", "weg_100",
#                                            "minute", "hour", "turn")], control = c("-c", "last", "-V", "last", "-S", "30", "-M", "100", "-length", "-3", "-I", "0.1"))
# 
#   poor_classifier <- make_r_function (model = new_model)
# 
#   quote <- c()
#   for (i in 1:nrow (combined))
#   {
#     if (anyNA (combined[i,]))
#     {
#       quote <- c (quote, 0.54)
#       next
#     }
#     quote <- c (quote, poor_classifier (combined[i,]))
#   }
# 
# #train$quote <- as.numeric (quote[, "win"])
# #combined$quote <- as.numeric (quote[, "win"])
# #combined$quote <- poor_classifier (combined)
# combined$quote <- round (quote, 2)
# 
# #cal_erg <- prCalibrate (r.calib = as.numeric (train$turn) - 1, p.calib = train$quote)
# #cal <- cal_erg$cal.probs
# #combined$quote <- round (cal, 2)
# 
# #print ("Medianfehler: " + round (median (as.numeric (abs (combined$Close - combined$prediction)), na.rm = T), 2))
# 
# bereich <- prepare_plot (combined$Close, combined$test1)["2020-04-22"]
# bereich_turn <- will_turn (as.numeric (bereich$test1))
# 
# # bei 0 reset
# # wenn win win dann win mit kleinerem test1 weg
# for (i in 1:length (bereich_turn))
# {
#   #b
# }
# 
# 
# weg <- which (abs (bereich$test1) < 20)
# #labels <- as.numeric (bereich$quote["2020-04-16"])
# labels <- as.character (bereich_turn)
# #labels <- rep ("", nrow (bereich))
# #labels[which (labels < as.numeric (quantile (bereich$quote, p = 0.6)))] <- ""
# #labels[which ((bereich_turn == "win") & (abs (bereich$test1) >= 70))] <- "win"
# labels[weg] <- ""
# bereich <- prepare_plot (combined$test1, combined$test1)["2020-04-22"]
# mplot (bereich, pos = c(0, 1), labels = labels)
# 
