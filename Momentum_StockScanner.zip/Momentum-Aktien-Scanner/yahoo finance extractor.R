library (xts)
library (stringr)
library (jsonlite)
Sys.setenv (TZ = "Europe/Berlin")

remove_list <- function (element)
{
   if (class (element) == "list") element <- element[[1]]
   return (element)
}

get_stock_data_yahoo <- function (symbol = "KSS",
                                  interval = "5m", # Sonst fehlen ggfs. Daten
                                  ts_end = "now",
                                  steps_back = 0,
                                  output = NA,
                                  k = 4,
                                  days_back = 20)
{
   if (ts_end == "now")
   {
      ts_end <- round (as.numeric (Sys.time()), 0)
   }
   ts_start <- round (ts_end - 60 * 60 * 24 * days_back, 0)
   
   server <- sample (c ("1", "2"), 1)
   url <- "https://query" + server + ".finance.yahoo.com/v8/finance/chart/" + symbol + "?" + 
      "symbol=" + symbol +
      "&period1=" + ts_start + 
      "&period2=" + ts_end + 
      "&interval=" + interval + 
      "&includePrePost=true" + 
      "&events=div%7Csplit%7Cearn" + 
      "&lang=en-US" + 
      "&region=US" + 
      "&crumb=wzCxbX7941K" + 
      "&corsDomain=finance.yahoo.com"

   x <- grab_url (url)
   x <- stringr::str_replace_all (as.character (x), fixed (",null"), ",0")
   y <- fromJSON (x)
   
   temp <- remove_list (y$chart$result)
   timestamp <- remove_list (temp$timestamp)
   
   temp2 <- remove_list (temp$indicators$quote)

   check <- try (open <- round (remove_list (temp2$open), 5), silent = T)
   if (class (check) == "try-error") return (NA)
   high <- round (remove_list (temp2$high), 5)
   low <- round (remove_list (temp2$low), 5)
   close <- round (remove_list (temp2$close), 5)
   volume <- round (remove_list (temp2$volume), 5)
   
   data <- data.frame (open, high, low, close, volume)
   colnames (data) <- c ("Open", "High", "Low", "Close", "Volume")
   
   timestamp_posix <- as.POSIXlt (timestamp, origin = "1970-01-01 00:00.00 UTC", tz = Sys.timezone())
   result <- as.xts (data, order.by = timestamp_posix)
   
   result <- result[which (!is.na (result$Open)), ]
   result <- result[which (result$Close != 0), ]
   result <- result[which (result$Open != 0), ]
   result <- result[which (result$High != 0), ]
   result <- result[which (result$Low != 0), ]
   
   # Fix last bar (Strange Yahoo-Data)
   # result <- result[1:nrow (result) - 1,]
   
   if (steps_back > 0)
   {
      result <- rbind.xts (get_stock_data_yahoo (symbol = symbol,
                                                 interval = interval,
                                                 ts_end = ts_start,
                                                 steps_back = steps_back - 1,
                                                 output = output,
                                                 k = k), result)
   }
   
   if (!identical (output, NA)) result <- to.period (result, output, k = k)
   colnames (result) <- c ("Open", "High", "Low", "Close", "Volume")
   result <- result[which (!duplicated (index (result))),]
   return (result)
}
