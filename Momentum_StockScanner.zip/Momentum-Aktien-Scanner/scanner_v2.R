

#---------Heikos Bibliothek---------

library (quantmod)
library (tidyquant)
library (foreach)
library (stringr)
library (R.utils)
library (jsonlite)
library (httr)
library (pracma)
library (future.apply)
library (ggplot2)
library (ggthemes)
library (ggrepel)
library (cowplot)
library (TTR)
#Imports#financial math functions, trading plots, foreach, string functions, misc, json, http#math functions, future concept, plots, plot themes, plot labels, more plots, trading functions
options (max.print = 100000) # Standard 1000

# Hilfsfunktion: + =   String-Konkatenation
#"+" <- function(...) UseMethod("+") 
#"+.default" <- .Primitive("+") 
#"+.character" <- function(...) paste(...,sep="")

options (scipen = 999)
options (future.globals.maxSize = +Inf)

a <- read.csv ("C:\\Users/timme/Desktop/Forschungspraktikum/Momentum-Aktien-Scanner/alle_ishares.csv", sep = ";", header = T)
# Manuell starten!
if (1 == 1)
{
  #setwd ("C:\\A")
  setwd ("C:\\Users/timme/Desktop/Forschungspraktikum/Momentum-Aktien-Scanner/")
  source ("yahoo finance extractor.R")
  #source ("ig daten.R")
  source ("xts plots.R")
  source ("hilfsfunktionen.R")
  source ("pairs2.R")
}
#------------Anfang des Momentumcodes-----------------------
plan (sequential)

#y <- get_stock_data_yahoo ("SPY", interval = "1d", steps_back = 0, days_back = 300)
#y <- tail (y, 200)

if ((!exists ("isin_db")) | (!exists ("isin_db2"))) load_isin_db()

dax_isins <- as.character (isin_db[which (isin_db$Product.Assignment.Group.Description == "DAX"),]$ISIN)
mdax_isins <- as.character (isin_db[which (isin_db$Product.Assignment.Group.Description == "MDAX"),]$ISIN)
sdax_isins <- as.character (isin_db[which (isin_db$Product.Assignment.Group.Description == "SDAX"),]$ISIN)
aktien_weltweit <- isin_db[which (isin_db$Product.Assignment.Group %in% setdiff (isin_db$Product.Assignment.Group, c ("FON1", "FONA", "FON0", "ETC1", "ETN0", "FDL0"))), "ISIN"]

#ishares_isins <- read.csv ("c:\\a\\ishares_isins.csv")[, 1]
ishares_isins <- read.csv ("C:\\Users/timme/Desktop/Forschungspraktikum/Aktien Scanner/ishares_isins.csv")[, 1]
alle_etfs <- unique (union (ishares_isins, isin_db4$ISIN))

liste_kurz <- c (dax_isins, mdax_isins, sdax_isins)

liste <- unique (c (liste_kurz, as.character (isin_db3$ISIN)))


#-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-

if (!exists ("cache")) cache <- list()




check_stock <- function (isin, do_plot = F, rv = F){
  # Hilfsfunktion: + = String-Konkatenation
  #"+" <<- function(...) UseMethod("+")
  #"+.default" <<- .Primitive("+")
  #"+.character" <<- function(...) paste(...,sep="")
  
  symbol <- isin_to_symbol_yahoo (isin)
  if (identical (symbol, NA)) return (NA)
  if (is.null (cache[[isin]]))
  {
    x <- get_stock_data_yahoo (symbol, interval = "1d", steps_back = 0, days_back = 300)
    #x <- gettex_kurse (isin)
    x <- tail (x, 200)
    cache[[isin]] <<- x
  }
  else
  {
    x <- cache[[isin]]
  }
  
  if (identical (x, NA)) return (NA)
  if (any (x$Close == 0)) return (NA)
  if (nrow (x) < 50) return (NA)
  
  x <- xts:::.drop.time (x)
  
  #y <<- xts:::.drop.time (y)
  
  #z <- prepare_plot (x, y)
  #z <- z[which (!is.na (z$Close)),]
  #z <- z[which (!is.na (z$Close.1)),]
  x <- x[which (!is.na(x$Close)),]
  
  #------------------------------
  lastprice <- as.numeric (tail (x$Close, 1))
  # Schleife um Differenzen zu berechnen: Momentum der letzten 10 Tage.
  for (i in 11:nrow(x$Close))
  {
  x$Momentum <- as.numeric (x$Close[[i]] - x$Close[[i-10]])
  }
  #------------------------------
  
  
  ma_volume_90 <- runningfunction (x$Volume, "mean", 90)
  ma_volume_7 <- runningfunction (x$Volume, "mean", 7)
  r_volume <- round (ma_volume_7 / ma_volume_90, 2)
  
  result <- list()
  result$r_volume <- as.numeric (tail (r_volume, 1))
  result$price <- lastprice
  result$isin <- isin
  result$momentum <- as.numeric (tail (x$Momentum, 1))
  
  # result$symbol <- symbol
  result$name <- id_to_name (isin) # gettex_info (isin)$name
  
  if (is.na (result$name))
  {
    result$name <- c (a[which (a$ISIN == isin),]$Name.der.Anteilklasse,
                      isin_db[which (isin_db$ISIN == isin),]$Instrument)[1]
  }
  isin_db[which (isin_db$ISIN == isin),]$Instrument
  if (length (result$name) == 0) result$name = ""
  

if (do_plot)
{
  try (crash_workaround <- dev.off (dev.list()["RStudioGD"]), silent = T)
  if (rv)
  {
    mplot (data.frame (x$Close, r_volume),
           pos = c (0, 1),
           title = paste ("Stock chart of ", result$name, " (", result$isin, ")", sep = ""),
           colors = c ("red", "red"))
  }
  else
  {
    mplot (data.frame (x$Close, x$Momentum),
           pos = c (0, 1),
           title = paste ("Momentum Analysis of ", result$name, " (", result$isin, ")", sep = ""),
           colors = c ("red", "blue"))      
  }
}
print (isin + " - " + result$momentum)
return (result)
}
#-----------------------------------------------
check_stock2 <- function (isin)
{
  #Sys.sleep (60)
  check <- try (result <- check_stock (isin), silent = T)
  
  if (class (check) == "try-error")
  {
    print (check)
    return (NA)
  }
  
  return (result)
}

#--------------------------------------------
#????
ch <- function (isin)
{
  try (crash_workaround <- dev.off (dev.list()["RStudioGD"]), silent = T)
  infos <- gettex_info (isin)
  chartSeries (tail (gettex_kurse (isin), 200), name = infos$name + " (" + isin + ")")
}

#!!!!!!!!!!!!!---------------WENDET CHECK_STOCK AUF ALLE ISINS AN -----------BRAUCHEN WIR----
tmp <- future_sapply (ishares_isins, check_stock2, future.stdout = T, USE.NAMES = F)

#!!!!!!!!!!!!!---------------F�GT ERGEBNISSE AUS CHECK STOCK 2 IN DAS DATA FRAME EIN -----------BRAUCHEN WIR F�R TRENDS DATA FRAME----
result <- data.frame()
for (i in 1:length (tmp))
{
  if (identical (tmp[[i]], NA)) next
  result <- rbind (result, tmp[[i]])
}


#!!!!!!!!!!!!!---------------INDIVIDUELLE FILTERUNG VON ISINS -----------BRAUCHEN WIR MOMENTUM FILTERN----

#trends <- result[which ((result$quality_30 >= 0.4)
                        #& (result$quality_60 > 0.4)
                        #& (result$coefficient2 <= 0.02)),]

#!!!!!!!!!!!!!---------------SORTIERUNG DES DATA FRAMES -----------BRAUCHEN WIR MOMENTUM ZU SORTIEREN----

#trends <- trends[order (trends$quality_60, decreasing = T),]

View (trends)
stop ("Done")

for (i in 1:nrow (trends))
{
  print (check_stock (trends[i, "isin"], T))
  if (readline(">?") == "q") break
  print ("----------------------------------------------------")
}

write.table (result, "C:\\Users\timme/Desktop/Forschungspraktikum/Aktien Scanner/ergebnis.csv", sep = ",", eol = "\n", quote = F)
stop ("done")

#-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-

