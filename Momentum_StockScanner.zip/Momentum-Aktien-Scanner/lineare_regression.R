library (quantmod)
library (tidyquant)
library (foreach)
library (stringr)
library (R.utils)
library (jsonlite)
library (httr)
library (pracma)
library (future.apply)
library (ggplot2)
library (ggthemes)
library (ggrepel)
library (cowplot)
library (TTR)


# Ggfs. Libraries laden
if (!exists ("mplot"))
{
  setwd ("C:\\A")
  source ("yahoo finance extractor.R")
  source ("xts plots.R")
  source ("hilfsfunktionen.R")
  source ("pairs2.R")
}

# Abh�ngige Variable: Aktienkurs, wir wollen ihn aus der Zeit linear konstruieren (also als Gerade).
# Zun�chst: Aktienkurs naiv zusammenw�rfeln.
# (in der Praxis macht man das �ber Brown'sche Prozesse, nicht so!)
aktie <- c (100)
for (i in 1:100)
{
  aktie <- c (aktie, tail (aktie, 1) + sample (-3:3, 1))
}

# Dimension Zeit
zeit <- 1:length (aktie)

# Plotten: Aktie vs. Zeit
mplot (data.frame (aktie), title = "Plot der Aktie")

readline ("Dies ist der Plot des Aktienkurses, jetzt berechnen wir die Regressionsgerade... [Enter]")

# Mittelwerte
m_aktie <- mean (aktie)
m_zeit <- mean (zeit)

# Standardabweichungen
sd_aktie <- sd (aktie)
sd_zeit <- sd (zeit)

# Kovarianz
cov_aktie_zeit <- cov (aktie, zeit)

# Korrelation
cor_aktie_zeit <- cov_aktie_zeit / (sd_aktie * sd_zeit) # oder einfach: cor (aktie, zeit)

# Die Geradengleichung f�r unser Problem lautet:
# aktie = a * zeit + b  (allgemeine Geradengleichung a * x + b, wobei x hier unsere Messreihe, wie z.B. der Aktienkurs ist)
# Wie sind nun a und b zu bestimmen? z.B. �ber Optimierungsalgorithmus, jedoch besser im einfachen Fall: analytisch!

# Wie man auf die Formeln kommt, siehe Wikipedia oder irgendein einf�hrendes Analysis-Buch
a <- (sd_aktie / sd_zeit) * cor_aktie_zeit
b <- - (sd_aktie / sd_zeit) * cor_aktie_zeit * m_zeit + m_aktie

# Jetzt gelangen wir auf diese Gerade, sie findet die "optimale" (Residual varianzminimale) Gerade durch die Aktienpunkte
aktie_linear <- a * zeit + b

# Ergebnis plotten: Originalkurs vs. Regressionsgerade
mplot (data.frame (aktie, aktie_linear), title = "Aktie (Rot) vs. Regressionsgerade (Blau)")

# Was taugt das lineare Modell?
# Daf�r R^2 Wert bestimmen, berechnet mal ein paar Werte, wann ist R^2 am h�chsten? Was folgert ihr daraus?
print ("R^2: " + round (cor_aktie_zeit^2, 2))
